package Activities;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Activity1 {	
	static ArrayList<String> list =new ArrayList<String>();
	
	@BeforeEach
		void Setup() {
		list.add("apple");
		list.add("berry");
		}
	
	@Test
	public void InsertTest() {
		
		assertEquals(2, list.size(),"Otherwise Wrong Size");
		list.add(2,"pear");
		assertEquals(3, list.size(),"Otherwise Wrong Size");
		
		assertEquals("apple", list.get(0), "otherwise Wrong element");
        assertEquals("berry", list.get(1), "otherwise Wrong element");
        assertEquals("pear", list.get(2), "other wiseWrong element");
		
	}
	
	@Test
    public void replaceTest() {
        
        list.set(1, "mango");
 
        // Assert size of list
        System.out.println(list);
        assertEquals(5, list.size(), "Otherwise Wrong size");
        // Assert individual elements
        assertEquals("apple", list.get(0), "Wrong element");
        assertEquals("mango", list.get(1), "Wrong element");
    }
}

