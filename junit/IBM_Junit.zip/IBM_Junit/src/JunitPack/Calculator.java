package JunitPack;

public class Calculator {
   public int multiply(int a, int b) {
       return a * b;
    }
  
    public int add(int a, int b) {
       return a + b;
   }
	public static void main(String[] args) {
		System.out.println(2*3);
	}
}