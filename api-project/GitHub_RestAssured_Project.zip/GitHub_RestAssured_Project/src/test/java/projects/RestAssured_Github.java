package projects;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import static io.restassured.RestAssured.given;

public class RestAssured_Github {
	
	RequestSpecification reqSpec;
	ResponseSpecification resSpec;
	String ssh = "";
	public int id = 0;
	
	@BeforeClass
	public void setUp() {
		
		reqSpec= new RequestSpecBuilder()
				.setBaseUri("https://api.github.com")
				.setContentType(ContentType.JSON)
				.build();
		
		resSpec= new ResponseSpecBuilder()
				.expectContentType(ContentType.JSON)
				. build();
	}
	
	@Test(priority=1)
	public void postReq() {
		System.out.println("POST API");
		Response response = given()
				.spec(reqSpec)
				.header("accept", "application/vnd.github.v3+json" )
				.when()
				.auth()
				.preemptive()
				.basic("token","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")
				.body("\n" + 
						"{\n" + 
						"    \"title\": \"TestAPIKey\",\n" + 
						"    \"key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAAgQChRm1IbOoFGwRTyRDxtPRzoW/HjCE/NvMQi/RP7sTULTl8BQuu07V3hw4mKKb3/zxzdck584i6OK4+5y/ii+CEtzPtIgFrVpfg2hHPr19a/sPJZVLYturaWH61cu9Kmd2dbpRMix02rWKeFTzWeE3AKjmfaXMFI2dqTOsnXI9rrQ==\"\n" + 
						"}\n" + 
						"\n" + 
						"")
				.log().uri()
				.post("/user/keys");
				
		response.then().spec(resSpec);
		response.then().log().body();
		response.then().statusCode(201);
		id= response.jsonPath().getInt("id");
		System.out.println("Id of the inserted ssh public token is : "+id);
	}
	
	@Test(priority=2)
	public void getReq() {
		System.out.println("GET API");
		Response response = given()
				.spec(reqSpec)
				.auth()
				.preemptive()
				.basic("token","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")
				.log().uri()
				.get("/user/keys");
		
		response.then().log().body();
		response.then().statusCode(200);
		
				
	}
	
	@Test(priority=3)
	public void deleteReq() {
		System.out.println("DELETE API");
		Response response = given().spec(reqSpec)
				.auth()
				.preemptive()
				.basic("token","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")
				.pathParam("keyId", id)
				.when()
				.log().uri()
				.delete("/user/keys/{keyId}");
		
		response.then().log().body();
		response.then().statusCode(204);
	}
	

}
